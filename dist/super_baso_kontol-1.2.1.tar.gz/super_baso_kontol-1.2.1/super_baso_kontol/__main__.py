if __name__ == "__main__":
    from rich import print
    def jsons():
        return {
                "name": "baso kontol",
                "repo": "https://github.com/b4ko_peneker",
                "default": "pass"
                }
    print(jsons())


