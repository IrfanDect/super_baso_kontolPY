def main():
    print("require token and cookies")
